# Rapport de Sécurité Fonctionnelle - Conforme ISO 26262
## Projet : CarDashboard & UDS Gateway (Automotive Embedded Systems)

### 1. Introduction & Objectif
Ce document formalise l'application des principes directeurs de la norme **ISO 26262** (Functional Safety for Road Vehicles) sur notre architecture embarquée (ESP32 + Serveur Flask + Bus CAN UDS). L'objectif est de garantir un niveau de intégrité **ASIL B** pour la surveillance critique du groupe motopropulseur (température de surchauffe et tension batterie).

---

### 2. Analyse des Dangers & Évaluation des Risques (HARA - Hazard Analysis and Risk Assessment)
Conformément à la partie 3 de l'ISO 26262, les risques potentiels identifiés sont :
* **Dangers :** 
  * Surchauffe moteur critique ($T > 40^\circ C$) non détectée $
ightarrow$ Risque de casse moteur.
  * Perte de communication avec le capteur (Capteur Hors Ligne) $
ightarrow$ Aveuglement du conducteur face à un danger thermique.
* **Classification ASIL :** 
  * Surchauffe : **ASIL B** (S2, E2, C2).

---

### 3. Concept de Sécurité Fonctionnelle (FSC - Functional Safety Concept)
Pour répondre au niveau ASIL B, les mesures de sécurité suivantes ont été intégrées dans le code source (`server.py` et `uds.py`) :
1. **Mécanisme de Watchdog & Heartbeat (Détection de Perte de Lien) :**
   * Si l'ESP32 cesse d'envoyer des données pendant plus de 30 secondes (`ATTENTE_HORS_LIGNE`), le système bascule dans un **État Sûr (Safe State)** et déclenche une alerte critique sur le Dashboard et par notification mobile (ntfy).
2. **Plages de Sécurité et Bornage des Entrées (Range Checks) :**
   * Filtrage et validation stricts des valeurs de température et de tension pour éviter les injections de fausses données ou les corruptions de buffer CAN.
3. **Diagnostic UDS (ISO 14229) et Codes Défauts (DTC) :**
   * En cas de dépassement de seuil thermique ($T > 35^\circ C$), l'ECU simulé enregistre le code défaut **DTC P0118** (température trop élevée) ; un capteur muet depuis plus de 30 s génère **U0100**. Lecture via le service UDS `19 02 FF` (réponse `59 02 09 <DTC 3 octets> <statut>`), effacement via `14 FF FF FF`.

---

### 4. Traçabilité Matériel & Logiciel
* **Câblage Matériel :** Utilisation d'une résistance de tirage (pull-up) de $4.7\,k\Omega$ sur le GPIO 4 pour fiabiliser les signaux du capteur DHT11.
* **Sécurité d'Accès UDS :** Le service d'écriture (WriteDataByIdentifier `0x2E`) est protégé par un mécanisme de sécurité **SecurityAccess (`0x27`)** accessible uniquement en session étendue (`10 03`), avec un Seed aléatoire à usage unique, une clé calculée avec le masque `0x4B3A2C1D`, et un verrouillage de 10 s après 3 clés fausses, évitant toute modification non autorisée du kilométrage ou des paramètres de l'ECU.
