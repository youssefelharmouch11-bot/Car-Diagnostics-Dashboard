"""Simule l'ESP32 : envoie température/humidité au serveur Flask."""
import json
import random
import time
import urllib.request

URL = "http://127.0.0.1:5000/api/update"
temp, hum = 24.0, 55.0

while True:
    temp += random.uniform(-0.4, 0.4)
    hum += random.uniform(-1.0, 1.0)
    corps = json.dumps({"temperature": round(temp, 1), "humidity": round(hum, 1)}).encode()
    req = urllib.request.Request(URL, corps, {"Content-Type": "application/json"})
    try:
        urllib.request.urlopen(req, timeout=3)
        print(f"Envoyé: {temp:.1f} °C / {hum:.1f} %")
    except Exception as e:
        print("Erreur d'envoi:", e)
    time.sleep(2)
