import hmac
import json
import os
import secrets
import sqlite3
import threading
import time
import urllib.request
from collections import deque
from datetime import datetime
from functools import wraps

from flask import Flask, jsonify, redirect, render_template, request, session, url_for
from flask_cors import CORS

import uds

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE, "config.json")
DB_FILE = os.path.join(BASE, "data.db")

def charger_config():
    defaut = {
        "username": "admin",
        "password": "admin123",
        "secret_key": secrets.token_hex(24),
        "ntfy_topic": "voiture-" + secrets.token_hex(5),
        "telegram_token": "",
        "telegram_chat_id": "",
    }
    cfg, lisible = {}, True
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                cfg = json.load(f)
        except Exception:
            lisible = False
    manque = {k: v for k, v in defaut.items() if k not in cfg}
    cfg.update(manque)
    if manque and lisible:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
    return cfg

CFG = charger_config()
app = Flask(__name__)
app.secret_key = CFG["secret_key"]
CORS(app)

historique = deque(maxlen=60)

VEHICULES = [
    {"id": "golf8r", "nom": "Golf 8 R", "type": "Compacte sportive", "moteur": "2.0 TSI · 4Motion", "vidange_km": 15000},
    {"id": "m5", "nom": "BMW M5 Competition", "type": "Berline sportive", "moteur": "V8 4.4 biturbo", "vidange_km": 15000},
    {"id": "clio", "nom": "Renault Clio", "type": "Citadine", "moteur": "", "vidange_km": 10000},
    {"id": "sandero", "nom": "Dacia Sandero", "type": "Citadine", "moteur": "", "vidange_km": 10000},
    {"id": "logan", "nom": "Dacia Logan", "type": "Berline", "moteur": "", "vidange_km": 10000},
    {"id": "208", "nom": "Peugeot 208", "type": "Citadine", "moteur": "", "vidange_km": 10000},
]
ENTRETIEN = [
    ("vidange", "Vidange moteur", None, 80000),
    ("pneus", "Rotation des pneus", 10000, 82000),
    ("filtre", "Filtre d'habitacle", 15000, 85000),
]
KM_DEMO = 88600
SEUILS = {"temp": (15, 35), "hum": (30, 70)}
ATTENTE_HORS_LIGNE = 30

def sql(requete, params=(), ecrire=False):
    c = sqlite3.connect(DB_FILE, timeout=10)
    try:
        c.row_factory = sqlite3.Row
        rows = c.execute(requete, params).fetchall()
        if ecrire:
            c.commit()
        return rows
    finally:
        c.close()

def init_db():
    sql("CREATE TABLE IF NOT EXISTS mesures(ts REAL, temperature REAL, humidity REAL)", (), True)
    sql("CREATE INDEX IF NOT EXISTS i_ts ON mesures(ts)", (), True)
    sql("CREATE TABLE IF NOT EXISTS reglages(cle TEXT PRIMARY KEY, valeur TEXT)", (), True)

def reglage(cle, defaut=None):
    r = sql("SELECT valeur FROM reglages WHERE cle=?", (cle,))
    return r[0]["valeur"] if r else defaut

def set_reglage(cle, valeur):
    sql("INSERT INTO reglages VALUES(?,?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur", (cle, str(valeur)), True)

def vehicule_courant():
    vid = reglage("vehicule")
    return next((v for v in VEHICULES if v["id"] == vid), None)

def entretiens():
    km = float(reglage("km", KM_DEMO))
    v = vehicule_courant() or {}
    out = []
    for id_, nom, intervalle, last0 in ENTRETIEN:
        if intervalle is None:
            intervalle = v.get("vidange_km", 10000)
        intervalle = max(1.0, float(reglage("int_" + id_, intervalle)))
        last = float(reglage("last_" + id_, last0))
        restant = max(0.0, intervalle - (km - last))
        pct = round(max(0.0, min(100.0, restant / intervalle * 100)))
        out.append({"id": id_, "nom": nom, "restant_km": round(restant), "pct": pct,
                    "intervalle": round(intervalle), "last": round(last)})
    return out

deja_envoye = {}

def _post_json(url, payload):
    req = urllib.request.Request(url, json.dumps(payload).encode("utf-8"), {"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=8).read()

def envoyer(titre, message):
    ok = False
    if CFG["ntfy_topic"]:
        try:
            _post_json("https://ntfy.sh", {"topic": CFG["ntfy_topic"], "title": titre, "message": message, "priority": 4, "tags": ["warning"]})
            ok = True
        except Exception as e:
            print("ntfy:", e)
    if CFG["telegram_token"] and CFG["telegram_chat_id"]:
        try:
            _post_json(f"https://api.telegram.org/bot{CFG['telegram_token']}/sendMessage",
                       {"chat_id": CFG["telegram_chat_id"], "text": f"{titre}\n{message}"})
            ok = True
        except Exception as e:
            print("telegram:", e)
    return ok

def alertes_actives():
    out, now = [], time.time()
    for m in entretiens():
        if m["pct"] <= 15:
            if m["id"] == "vidange":
                out.append(("e_vidange", "Vidange à prévoir", f"Durée de vie de l'huile restante : {m['pct']} %", 24 * 3600))
            else:
                out.append(("e_" + m["id"], f"{m['nom']} à prévoir", f"Il reste {m['restant_km']} km", 24 * 3600))
    if historique:
        m = historique[-1]
        if now - m["ts"] > ATTENTE_HORS_LIGNE:
            out.append(("offline", "Capteur hors ligne", "Aucune donnée reçue de l'ESP32.", 1800))
        else:
            for cle, nom, val, unite in (("temp", "Température", m["temperature"], "°C"), ("hum", "Humidité", m["humidity"], "%")):
                lo, hi = SEUILS[cle]
                if not lo <= val <= hi:
                    out.append((cle, f"{nom} {'basse' if val < lo else 'élevée'}",
                                f"{nom} : {val:.1f} {unite} (optimal {lo}–{hi} {unite})", 1800))
    return out

def traiter(actives):
    now = time.time()
    cles = {a[0] for a in actives}
    for k in list(deja_envoye):
        if k not in cles:
            del deja_envoye[k]
    for cle, titre, msg, delai in actives:
        if now - deja_envoye.get(cle, 0) >= delai:
            deja_envoye[cle] = now
            threading.Thread(target=envoyer, args=(titre, msg), daemon=True).start()

def surveillance():
    while True:
        try:
            traiter(alertes_actives())
        except Exception:
            pass
        time.sleep(5)

echecs = {}

def trop_d_essais(ip):
    recents = [t for t in echecs.get(ip, []) if time.time() - t < 300]
    echecs[ip] = recents
    return len(recents) >= 5

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("auth"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

@app.route("/login", methods=["GET", "POST"])
def login():
    erreur = None
    if request.method == "POST":
        ip = request.remote_addr
        if trop_d_essais(ip):
            erreur = "Trop de tentatives. Réessaie dans 5 minutes."
        else:
            u_ok = hmac.compare_digest(request.form.get("username", "").encode(), CFG["username"].encode())
            p_ok = hmac.compare_digest(request.form.get("password", "").encode(), CFG["password"].encode())
            if u_ok and p_ok:
                session["auth"] = True
                return redirect(url_for("index"))
            echecs.setdefault(ip, []).append(time.time())
            erreur = "Nom d'utilisateur ou mot de passe incorrect."
    return render_template("login.html", erreur=erreur)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/vehicule", methods=["GET", "POST"])
@login_required
def vehicule():
    if request.method == "POST":
        choix = request.form.get("id")
        if choix == "autre":
            nom = request.form.get("nom", "").strip()[:40] or "Mon véhicule"
            session["vehicule"] = {"nom": nom, "type": "Personnalisé", "moteur": ""}
            set_reglage("vehicule", "autre")
            return redirect(url_for("index"))
        for v in VEHICULES:
            if v["id"] == choix:
                session["vehicule"] = {k: v[k] for k in ("nom", "type", "moteur")}
                set_reglage("vehicule", v["id"])
                return redirect(url_for("index"))
    return render_template("vehicule.html", vehicules=VEHICULES)

@app.route("/")
@login_required
def index():
    if not session.get("vehicule"):
        return redirect(url_for("vehicule"))
    return render_template("dashboard.html", v=session["vehicule"], defaut_mdp=CFG["password"] == "admin123")

@app.route("/parametres", methods=["GET", "POST"])
@login_required
def parametres():
    message = None
    if request.method == "POST":
        try:
            set_reglage("km", float(request.form["km"]))
            for id_, _, _, _ in ENTRETIEN:
                set_reglage("int_" + id_, float(request.form["int_" + id_]))
                set_reglage("last_" + id_, float(request.form["last_" + id_]))
            message = "Réglages enregistrés."
        except Exception:
            message = "Valeur invalide."
    return render_template("parametres.html", km=round(float(reglage("km", KM_DEMO))),
                           items=entretiens(), topic=CFG["ntfy_topic"], message=message)

@app.route("/api/update", methods=["POST"])
def update():
    data = request.get_json(silent=True) or {}
    try:
        mesure = {
            "temperature": float(data["temperature"]),
            "humidity": float(data["humidity"]),
            "time": datetime.now().strftime("%H:%M:%S"),
            "ts": time.time(),
        }
    except Exception:
        return jsonify({"error": "JSON attendu"}), 400
    historique.append(mesure)
    try:
        sql("INSERT INTO mesures VALUES(?,?,?)", (mesure["ts"], mesure["temperature"], mesure["humidity"]), True)
    except Exception:
        pass
    return jsonify({"status": "ok"})

@app.route("/api/data")
@login_required
def donnees():
    return jsonify({"latest": historique[-1] if historique else None, "history": list(historique),
                    "entretien": entretiens()})

@app.route("/api/historique")
@login_required
def historique_api():
    try:
        minutes = max(1, min(int(request.args.get("minutes", 60)), 60 * 24 * 30))
    except ValueError:
        minutes = 60
    debut, pas = time.time() - minutes * 60, max(1.0, minutes * 60 / 60)
    rows = sql("SELECT CAST((ts-?)/? AS INTEGER) b, AVG(temperature) t, AVG(humidity) h, MAX(ts) ts "
               "FROM mesures WHERE ts>=? GROUP BY b ORDER BY b", (debut, pas, debut))
    fmt = "%H:%M" if minutes <= 1440 else "%d/%m %H:%M"
    return jsonify([{"temperature": r["t"], "humidity": r["h"],
                     "time": datetime.fromtimestamp(r["ts"]).strftime(fmt)} for r in rows])

@app.route("/api/entretien/<id_>/fait", methods=["POST"])
@login_required
def entretien_fait(id_):
    if id_ not in [e[0] for e in ENTRETIEN]:
        return jsonify({"ok": False}), 404
    set_reglage("last_" + id_, reglage("km", KM_DEMO))
    return jsonify({"ok": True})

@app.route("/api/test-notif")
@login_required
def test_notif():
    ok = envoyer("Test CarDashboard", "Notifications opérationnelles ✅")
    return jsonify({"ok": ok, "msg": "Notification envoyée sur votre téléphone." if ok else "Échec de l'envoi."})

init_db()
uds.init_app(app, sql)

if __name__ == "__main__":
    print("\n  CarDashboard avec UDS Pro démarré sur le port 5000...\n")
    threading.Thread(target=surveillance, daemon=True).start()
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)
