# Car Diagnostics Dashboard (ESP32 + Flask)

Un ESP32 lit la température et l'humidité avec un capteur DHT11 et les envoie en HTTP à un serveur Flask.
Le serveur les affiche en temps réel sur un dashboard web protégé par un login.

## Contenu

| Fichier | Rôle |
|---|---|
| `server.py` | Serveur Flask : login, API `/api/update` (réception) et `/api/data` (lecture) |
| `templates/login.html` | Page de connexion |
| `templates/dashboard.html` | Dashboard temps réel (valeurs + graphique) |
| `esp32_car_monitor.ino` | Code de l'ESP32 (WiFi + DHT11 + envoi HTTP POST) |
| `dht_test.ino` | Test du capteur seul, sans WiFi |
| `simulateur.py` | Simule l'ESP32 pour tester sans matériel |

## Matériel

- ESP32
- Capteur DHT11
- Résistance de 4,7 à 10 kΩ (pull-up)
- Câble USB

Câblage : `VCC → 3,3 V`, `GND → GND`, `DATA → GPIO 4`, et la résistance entre `DATA` et `VCC`.

## 1. Serveur Flask

```bash
pip install -r requirements.txt
python server.py
```

Le serveur écoute sur le port 5000. Ouvre `http://127.0.0.1:5000` et connecte-toi avec `admin` / `admin123`
(change ces valeurs dans `server.py`).

### Test sans ESP32

Dans un deuxième terminal, dans le même dossier :

```bash
python simulateur.py
```

## 2. ESP32

1. Installe l'Arduino IDE, puis le support de carte **esp32** (Gestionnaire de cartes).
2. Installe la bibliothèque **DHT sensor library** (Adafruit).
3. Téléverse d'abord `dht_test.ino` et ouvre le moniteur série (115200) : tu dois voir des valeurs.
4. Ouvre `esp32_car_monitor.ino` et modifie :
   - `WIFI_SSID` et `WIFI_PASSWORD`
   - `SERVER_URL` : `http://IP_DE_TON_PC:5000/api/update`
5. Choisis la carte **ESP32 Dev Module**, le bon port, et téléverse.

Pour trouver l'IP de ton PC : `ipconfig` dans cmd, ligne **Adresse IPv4**.
Le PC et l'ESP32 doivent être sur le même réseau WiFi.

## 3. Dashboard

Ouvre `http://IP_DE_TON_PC:5000` dans un navigateur du même réseau.

## Problèmes fréquents

- **`Failed to read from DHT sensor`** : vérifie le câblage, la résistance, l'alimentation 3,3 V, puis reteste avec `dht_test.ino`.
- **Erreur 400 `Bad request version` côté serveur** : l'ESP32 envoie du HTTPS. L'URL doit commencer par `http://`.
- **L'ESP32 n'arrive pas au serveur (code -1)** : le pare-feu Windows bloque souvent le port 5000. Autorise Python dans le pare-feu, et vérifie que l'IP est la bonne.
- **`pip` : SyntaxError** : tu es dans l'interpréteur Python (`>>>`). Lance les commandes `pip` dans cmd ou PowerShell.

## Notifications sur le téléphone

Quand une alerte apparaît (ex. « Vidange à prévoir », température hors plage, capteur hors ligne), le serveur envoie un message sur ton téléphone.

**Avec ntfy (gratuit, sans compte) :**
1. Installe l'application **ntfy** sur ton téléphone (Android ou iPhone).
2. Lance le serveur : il affiche (et la page **Paramètres** montre) un nom de sujet généré automatiquement, par exemple `voiture-3fa9c2d1b7`. Quiconque connaît ce nom peut lire les messages.
3. Dans l'app : « + » → saisis ce nom → S'abonner.
4. (Optionnel) Tu peux changer le nom dans `config.json` (`ntfy_topic`), puis relancer le serveur.
5. Clique sur **Tester la notification téléphone** dans le dashboard.

Le PC qui fait tourner le serveur doit avoir accès à Internet. Chaque alerte est envoyée une seule fois (puis de nouveau après 30 min, ou 24 h pour la vidange).

**Avec Telegram (optionnel) :** crée un bot avec @BotFather, puis renseigne `telegram_token` et `telegram_chat_id` dans `config.json`.

## Configuration et sécurité

Au premier lancement, `config.json` est créé automatiquement. Ouvre-le dans le Bloc-notes pour changer `username` et `password` (le mot de passe par défaut `admin123` déclenche un avertissement dans le dashboard). Après 5 mauvais mots de passe, la connexion est bloquée 5 minutes.

## Entretien, historique et réglages

- Page **Paramètres** : kilométrage actuel, dernier entretien et intervalle (huile, pneus, filtre). Le dashboard calcule le reste en km et envoie une alerte téléphone sous 15 %.
- Bouton **Fait** : marque un entretien comme réalisé au kilométrage actuel.
- Les mesures sont enregistrées dans `data.db` (30 jours conservés). Le graphique propose Direct, 1 h, 24 h et 7 j.
- Les intervalles de vidange par véhicule (liste `VEHICULES` dans `server.py`) sont des valeurs par défaut : adapte-les au carnet d'entretien.


## Conformité Normes Automobiles
- **ISO 14229 (UDS)** : Diagnostic complet (Sessions, SecurityAccess, DID, DTC).
- **ISO 26262** : Rapport de sécurité fonctionnelle (ASIL B, gestion des états sûrs et DTC P0117).


## Diagnostic UDS (page `/diagnostic`)

Séquence pour modifier le kilométrage (le timer de session S3 est de 5 s) :

| Étape | Requête | Réponse attendue |
|---|---|---|
| 1 | `10 03` | `50 03 00 32 01 F4` |
| 2 | `27 01` | `67 01 <seed 4 octets>` |
| 3 | `27 02 <seed XOR 4B3A2C1D>` | `67 02` |
| 4 | `2E 02 00 <km sur 4 octets>` | `6E 02 00` |

Le bouton « Déverrouiller » de la page fait les étapes 1 à 3 automatiquement.
Autres services : `22 F1 90` (VIN), `22 01 00` (capteurs), `22 02 00` (km), `19 02 FF` (DTC), `14 FF FF FF` (effacer DTC), `11 01` (reset), `3E 00` (tester present).
