"""ECU simulé + diagnostic UDS (ISO 14229) sur ISO-TP (ISO 15765-2).

Services supportés : 10, 11, 14, 19, 22, 27, 2E, 3E.
"""
import secrets
import threading
import time
from functools import wraps

from flask import jsonify, redirect, render_template, request, session, url_for

MASQUE_CLE = 0x4B3A2C1D
VIN = b"WVWZZZCDZMW000123"          # 17 caractères
TIMEOUT_SESSION = 5.0               # S3 server : retour en session par défaut
MAX_ESSAIS = 3
VERROU_SECONDES = 10.0

# NRC (codes de réponse négative)
NRC_SERVICE_NON_SUPPORTE = 0x11
NRC_SOUS_FONCTION_NON_SUPPORTEE = 0x12
NRC_LONGUEUR_INCORRECTE = 0x13
NRC_HORS_PLAGE = 0x31
NRC_ACCES_REFUSE = 0x33
NRC_CLE_INVALIDE = 0x35
NRC_TROP_D_ESSAIS = 0x36
NRC_DELAI_ATTENTE = 0x37
NRC_ERREUR_SEQUENCE = 0x24
NRC_NON_SUPPORTE_EN_SESSION = 0x7F

# DTC : code -> (octets DTC sur 3, description)
DTC_TABLE = {
    "P0118": (bytes([0x01, 0x18, 0x00]), "Température trop élevée"),
    "P0117": (bytes([0x01, 0x17, 0x00]), "Température trop basse"),
    "P0562": (bytes([0x05, 0x62, 0x00]), "Tension batterie trop basse"),
    "U0100": (bytes([0xC1, 0x00, 0x00]), "Perte de communication capteur (ESP32)"),
}
STATUT_ACTIF = 0x09   # testFailed + confirmedDTC
SEUIL_TEMP = (15.0, 35.0)


# ---------- utilitaires hex / ISO-TP ----------
def hex_vers_bytes(chaine_hex):
    propre = chaine_hex.replace(" ", "").replace(",", "")
    if propre.lower().startswith("0x"):
        propre = propre[2:]
    return bytes.fromhex(propre)


def vers_hex(donnees):
    return " ".join(f"{b:02X}" for b in donnees)


def trames_can(payload, can_id=0x7E8):
    """Découpe une réponse UDS en trames CAN ISO-TP (SF ou FF + FC + CF)."""
    n = len(payload)
    if n <= 7:
        return [(can_id, vers_hex(bytes([n]) + payload + b"\xAA" * (7 - n)))]
    trames = [(can_id, vers_hex(bytes([0x10 | ((n >> 8) & 0x0F), n & 0xFF]) + payload[:6]))]
    trames.append((0x7E0, vers_hex(bytes([0x30, 0x00, 0x00]) + b"\xAA" * 5)))
    idx, sn = 6, 1
    while idx < n:
        chunk = payload[idx:idx + 7]
        trames.append((can_id, vers_hex(bytes([0x20 | sn]) + chunk + b"\xAA" * (7 - len(chunk)))))
        idx += 7
        sn = (sn + 1) % 16
    return trames


def neg(sid, nrc):
    return bytes([0x7F, sid, nrc])


# ---------- ECU ----------
class ECUSimule:
    def __init__(self, sql):
        self.sql = sql
        self.lock = threading.RLock()
        self.session_type = 0x01
        self.security_unlocked = False
        self.seed = None
        self.essais = 0
        self.verrou_jusqua = 0.0
        self.last_req_time = time.time()
        self.dtcs = {}  # code -> statut (mémoire de défauts)

    # --- accès données ---
    def derniere_mesure(self):
        rows = self.sql("SELECT ts, temperature, humidity FROM mesures ORDER BY ts DESC LIMIT 1")
        return rows[0] if rows else None

    def km(self):
        rows = self.sql("SELECT valeur FROM reglages WHERE cle='km'")
        return int(float(rows[0]["valeur"])) if rows else 88600

    def set_km(self, valeur):
        self.sql("INSERT INTO reglages VALUES('km',?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur",
                 (str(valeur),), True)

    def maj_dtcs(self):
        m = self.derniere_mesure()
        if m is None:
            return
        if time.time() - m["ts"] > 30:
            self.dtcs["U0100"] = STATUT_ACTIF
        if m["temperature"] > SEUIL_TEMP[1]:
            self.dtcs["P0118"] = STATUT_ACTIF
        elif m["temperature"] < SEUIL_TEMP[0]:
            self.dtcs["P0117"] = STATUT_ACTIF

    # --- session ---
    def check_timeout(self):
        if self.session_type != 0x01 and time.time() - self.last_req_time > TIMEOUT_SESSION:
            self.session_type = 0x01
            self.security_unlocked = False
            self.seed = None

    def traiter_requete(self, req):
        with self.lock:
            self.check_timeout()
            self.last_req_time = time.time()
            if not req:
                return neg(0x00, NRC_LONGUEUR_INCORRECTE), "Requête vide"
            sid = req[0]
            handler = {0x10: self.s10, 0x11: self.s11, 0x14: self.s14, 0x19: self.s19,
                       0x22: self.s22, 0x27: self.s27, 0x2E: self.s2e, 0x3E: self.s3e}.get(sid)
            if handler is None:
                return neg(sid, NRC_SERVICE_NON_SUPPORTE), "Service non supporté"
            return handler(req)

    # --- 0x10 DiagnosticSessionControl ---
    def s10(self, req):
        if len(req) != 2:
            return neg(0x10, NRC_LONGUEUR_INCORRECTE), "Longueur incorrecte"
        st = req[1] & 0x7F
        if st not in (0x01, 0x02, 0x03):
            return neg(0x10, NRC_SOUS_FONCTION_NON_SUPPORTEE), "Session non supportée"
        self.session_type = st
        self.security_unlocked = False   # tout changement de session reverrouille
        self.seed = None
        noms = {1: "par défaut", 2: "programmation", 3: "étendue"}
        # P2 = 50 ms (0x0032), P2* = 5000 ms (0x01F4 x 10 ms)
        return bytes([0x50, st, 0x00, 0x32, 0x01, 0xF4]), f"Session {noms[st]} (0x{st:02X})"

    # --- 0x11 ECUReset ---
    def s11(self, req):
        if len(req) != 2:
            return neg(0x11, NRC_LONGUEUR_INCORRECTE), "Longueur incorrecte"
        sub = req[1] & 0x7F
        if sub not in (0x01, 0x02, 0x03):
            return neg(0x11, NRC_SOUS_FONCTION_NON_SUPPORTEE), "Type de reset non supporté"
        self.session_type = 0x01
        self.security_unlocked = False
        self.seed = None
        noms = {1: "hard reset", 2: "key off/on", 3: "soft reset"}
        return bytes([0x51, sub]), f"ECU Reset ({noms[sub]})"

    # --- 0x3E TesterPresent ---
    def s3e(self, req):
        if len(req) != 2:
            return neg(0x3E, NRC_LONGUEUR_INCORRECTE), "Longueur incorrecte"
        if req[1] & 0x7F != 0x00:
            return neg(0x3E, NRC_SOUS_FONCTION_NON_SUPPORTEE), "Sous-fonction non supportée"
        return bytes([0x7E, 0x00]), "Tester Present ACK (timer de session relancé)"

    # --- 0x22 ReadDataByIdentifier (plusieurs DID possibles) ---
    def s22(self, req):
        if len(req) < 3 or (len(req) - 1) % 2:
            return neg(0x22, NRC_LONGUEUR_INCORRECTE), "Longueur invalide"
        rep, noms = bytearray([0x62]), []
        for i in range(1, len(req), 2):
            did = (req[i] << 8) | req[i + 1]
            donnees = self.lire_did(did)
            if donnees is None:
                return neg(0x22, NRC_HORS_PLAGE), f"DID 0x{did:04X} non supporté"
            rep += bytes([req[i], req[i + 1]]) + donnees
            noms.append(f"0x{did:04X}")
        return bytes(rep), "Lecture " + ", ".join(noms)

    def lire_did(self, did):
        if did == 0xF190:
            return VIN
        if did == 0x0100:
            m = self.derniere_mesure()
            t = int(round(m["temperature"])) if m else 24
            h = int(round(m["humidity"])) if m else 55
            bat = 127  # 12,7 V (x10), valeur simulée
            return bytes([t & 0xFF, h & 0xFF, (bat >> 8) & 0xFF, bat & 0xFF])
        if did == 0x0200:
            return self.km().to_bytes(4, "big")
        return None

    # --- 0x27 SecurityAccess ---
    def s27(self, req):
        if len(req) < 2:
            return neg(0x27, NRC_LONGUEUR_INCORRECTE), "Longueur invalide"
        if self.session_type == 0x01:
            return neg(0x27, NRC_NON_SUPPORTE_EN_SESSION), "SecurityAccess interdit en session par défaut"
        sub = req[1]
        if sub == 0x01:                               # requestSeed
            if len(req) != 2:
                return neg(0x27, NRC_LONGUEUR_INCORRECTE), "Longueur invalide"
            if time.time() < self.verrou_jusqua:
                return neg(0x27, NRC_DELAI_ATTENTE), "Délai d'attente requis après trop d'essais"
            if self.security_unlocked:
                return bytes([0x67, 0x01, 0, 0, 0, 0]), "Déjà déverrouillé (seed = 0)"
            self.seed = secrets.randbelow(0xFFFFFFFF) + 1
            return bytes([0x67, 0x01]) + self.seed.to_bytes(4, "big"), "Seed aléatoire généré"
        if sub == 0x02:                               # sendKey
            if len(req) != 6:
                return neg(0x27, NRC_LONGUEUR_INCORRECTE), "Clé de 4 octets attendue"
            if self.seed is None:
                return neg(0x27, NRC_ERREUR_SEQUENCE), "Demandez d'abord un seed (27 01)"
            if time.time() < self.verrou_jusqua:
                return neg(0x27, NRC_DELAI_ATTENTE), "Délai d'attente requis après trop d'essais"
            cle = int.from_bytes(req[2:6], "big")
            if cle == (self.seed ^ MASQUE_CLE):
                self.security_unlocked, self.essais, self.seed = True, 0, None
                return bytes([0x67, 0x02]), "Sécurité déverrouillée"
            self.essais += 1
            self.seed = None                          # un seed ne sert qu'une fois
            if self.essais >= MAX_ESSAIS:
                self.verrou_jusqua = time.time() + VERROU_SECONDES
                self.essais = 0
                return neg(0x27, NRC_TROP_D_ESSAIS), "Trop d'essais : verrouillé 10 s"
            return neg(0x27, NRC_CLE_INVALIDE), f"Clé invalide ({self.essais}/{MAX_ESSAIS})"
        return neg(0x27, NRC_SOUS_FONCTION_NON_SUPPORTEE), "Sous-fonction non supportée"

    # --- 0x2E WriteDataByIdentifier ---
    def s2e(self, req):
        if len(req) != 7:
            return neg(0x2E, NRC_LONGUEUR_INCORRECTE), "Format : 2E <DID 2 octets> <4 octets>"
        if self.session_type == 0x01:
            return neg(0x2E, NRC_NON_SUPPORTE_EN_SESSION), "Écriture interdite en session par défaut"
        if not self.security_unlocked:
            return neg(0x2E, NRC_ACCES_REFUSE), "Sécurité verrouillée (securityAccessDenied)"
        did = (req[1] << 8) | req[2]
        if did != 0x0200:
            return neg(0x2E, NRC_HORS_PLAGE), "DID non inscriptible"
        nouveau = int.from_bytes(req[3:7], "big")
        if nouveau < self.km():
            return neg(0x2E, NRC_HORS_PLAGE), "Le kilométrage ne peut pas diminuer"
        self.set_km(nouveau)
        return bytes([0x6E, 0x02, 0x00]), f"Kilométrage mis à jour : {nouveau} km"

    # --- 0x19 ReadDTCInformation ---
    def s19(self, req):
        if len(req) < 2:
            return neg(0x19, NRC_LONGUEUR_INCORRECTE), "Longueur invalide"
        sub = req[1]
        if sub != 0x02 or len(req) != 3:
            return neg(0x19, NRC_SOUS_FONCTION_NON_SUPPORTEE), "Seul 19 02 <masque> est supporté"
        masque = req[2]
        self.maj_dtcs()
        rep = bytearray([0x59, 0x02, STATUT_ACTIF])  # StatusAvailabilityMask
        n = 0
        for code, statut in self.dtcs.items():
            if statut & masque:
                rep += DTC_TABLE[code][0] + bytes([statut])
                n += 1
        return bytes(rep), f"{n} DTC(s) correspondant au masque 0x{masque:02X}"

    # --- 0x14 ClearDiagnosticInformation ---
    def s14(self, req):
        if len(req) != 4:
            return neg(0x14, NRC_LONGUEUR_INCORRECTE), "Format : 14 <groupe 3 octets>"
        groupe = int.from_bytes(req[1:4], "big")
        if groupe != 0xFFFFFF:
            return neg(0x14, NRC_HORS_PLAGE), "Seul le groupe FFFFFF (tous les DTC) est supporté"
        n = len(self.dtcs)
        self.dtcs.clear()
        return bytes([0x54]), f"{n} DTC(s) effacé(s)"


def decoder_dtcs(rep):
    """Transforme une réponse 59 02 en liste lisible."""
    out = []
    for i in range(3, len(rep) - 3, 4):
        brut = rep[i:i + 3]
        code = next((c for c, (b, _) in DTC_TABLE.items() if b == brut), vers_hex(brut))
        out.append({"code": code, "statut": f"0x{rep[i + 3]:02X}",
                    "description": DTC_TABLE.get(code, (None, "Inconnu"))[1]})
    return out


ecu_instance = None


def init_app(app, sql):
    """`sql` est le helper sql(requete, params, ecrire) de server.py."""
    global ecu_instance
    ecu_instance = ECUSimule(sql)

    def login_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not session.get("auth"):
                if request.path.startswith("/api/"):
                    return jsonify({"error": "Non authentifié"}), 401
                return redirect(url_for("login"))
            return f(*args, **kwargs)
        return decorated

    @app.route("/diagnostic")
    @login_required
    def diagnostic():
        return render_template("diagnostic.html", v=session.get("vehicule") or {"nom": "Golf 8 R"})

    @app.route("/api/uds", methods=["POST"])
    @login_required
    def api_uds():
        data = request.get_json(silent=True) or {}
        chaine = str(data.get("requete", ""))
        try:
            req = hex_vers_bytes(chaine)
        except ValueError:
            return jsonify({"error": "Hexadécimal invalide (ex : 22 F1 90)"}), 400
        rep, desc = ecu_instance.traiter_requete(req)
        resultat = {
            "requete_hex": vers_hex(req),
            "reponse_hex": vers_hex(rep),
            "positive": rep[0] != 0x7F,
            "description": desc,
            "trames_can": trames_can(rep),
            "session": ecu_instance.session_type,
            "securite": ecu_instance.security_unlocked,
        }
        if rep[:2] == b"\x59\x02":
            resultat["dtcs"] = decoder_dtcs(rep)
        return jsonify(resultat)

    @app.route("/api/uds/etat")
    @login_required
    def api_etat():
        with ecu_instance.lock:
            ecu_instance.check_timeout()
            return jsonify({"session": ecu_instance.session_type, "securite": ecu_instance.security_unlocked})

    @app.route("/api/uds/cle/<seed_hex>")
    @login_required
    def api_cle(seed_hex):
        """Aide pédagogique : calcule la clé (seed XOR masque) pour 27 02."""
        try:
            seed = int(seed_hex.replace(" ", ""), 16)
        except ValueError:
            return jsonify({"error": "Seed invalide"}), 400
        return jsonify({"cle": f"{(seed ^ MASQUE_CLE) & 0xFFFFFFFF:08X}"})
